let num:number = 123
alert('hello')